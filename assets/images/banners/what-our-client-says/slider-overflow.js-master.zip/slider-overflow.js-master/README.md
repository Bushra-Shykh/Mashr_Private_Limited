Create your HTML ,

Import style.scss and Carousel.js,

Define your options like main.js

and everything is done, 

an exemple on my codepen : https://codepen.io/exoxdus/pen/XWbmLBe
