# Swiper Testimonial Slider Cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/davidklotz11/pen/xOxjMW](https://codepen.io/davidklotz11/pen/xOxjMW).

